package matter.constraint;

/**
 * methods for creating mouse constraints
 * not implemented as people use different GUI system
 * @author JohnC
 */
public class MouseConstraint {
    public Constraint constraint;
    public MouseConstraint() {

    }
    
    // static public MouseConstraint create() {
        
    // }
}